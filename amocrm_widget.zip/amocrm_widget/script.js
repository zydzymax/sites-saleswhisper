/**
 * Sales Whisper Manager Widget for AmoCRM/Kommo
 * AI-powered sales assistant for managers
 */
define(['jquery', 'underscore'], function($, _) {
    var CustomWidget = function() {
        var self = this;
        var w_code = self.get_settings().widget_code;

        /**
         * Get API URL from settings
         */
        this.getApiUrl = function() {
            return self.get_settings().api_url || 'https://saleswhisper.pro/api';
        };

        /**
         * Get API Key from settings
         */
        this.getApiKey = function() {
            return self.get_settings().api_key || '';
        };

        /**
         * Make API request to AI Seller backend
         */
        this.apiRequest = function(endpoint, method, data) {
            var deferred = $.Deferred();
            var url = this.getApiUrl() + endpoint;

            $.ajax({
                url: url,
                type: method || 'GET',
                data: data ? JSON.stringify(data) : null,
                contentType: 'application/json',
                headers: {
                    'X-API-Key': this.getApiKey()
                },
                success: function(response) {
                    deferred.resolve(response);
                },
                error: function(xhr, status, error) {
                    console.error('Sales Whisper API Error:', error);
                    deferred.reject(error);
                }
            });

            return deferred.promise();
        };

        /**
         * Render lead card panel with AI assistant
         */
        this.renderLeadCard = function() {
            var lead_id = AMOCRM.data.current_card.id;
            var $widget_panel = $('[data-id="' + w_code + '"]');

            if (!$widget_panel.length) {
                return false;
            }

            // Show loading state
            $widget_panel.html(self.render({
                ref: '/templates/loading.twig'
            }, {}));

            // Fetch AI assistant data
            self.apiRequest('/widget/lead/' + lead_id + '/assistant', 'GET')
                .then(function(data) {
                    $widget_panel.html(self.render({
                        ref: '/templates/lead_card.twig'
                    }, {
                        lead_id: lead_id,
                        lead_name: data.lead_name || '',
                        client_info: data.client_info || {},
                        conversation_history: data.conversation_history || [],
                        suggested_messages: data.suggested_messages || [],
                        deal_stage: data.deal_stage || 'new',
                        client_temperature: data.client_temperature || 'cold',
                        next_action: data.next_action || '',
                        talking_points: data.talking_points || [],
                        objections: data.objections || [],
                        auto_response_enabled: self.get_settings().auto_response || false
                    }));

                    // Bind actions after render
                    self.bindLeadCardActions($widget_panel);
                })
                .fail(function(error) {
                    $widget_panel.html(self.render({
                        ref: '/templates/error.twig'
                    }, {
                        error_message: self.i18n('error.load_failed')
                    }));
                });

            return true;
        };

        /**
         * Render contact card panel
         */
        this.renderContactCard = function() {
            var contact_id = AMOCRM.data.current_card.id;
            var $widget_panel = $('[data-id="' + w_code + '"]');

            if (!$widget_panel.length) {
                return false;
            }

            $widget_panel.html(self.render({
                ref: '/templates/loading.twig'
            }, {}));

            self.apiRequest('/widget/contact/' + contact_id + '/profile', 'GET')
                .then(function(data) {
                    $widget_panel.html(self.render({
                        ref: '/templates/contact_card.twig'
                    }, {
                        contact_id: contact_id,
                        contact_name: data.contact_name || '',
                        phone: data.phone || '',
                        total_interactions: data.total_interactions || 0,
                        personality_profile: data.personality_profile || {},
                        communication_style: data.communication_style || 'formal',
                        best_contact_time: data.best_contact_time || '',
                        interests: data.interests || [],
                        past_objections: data.past_objections || []
                    }));
                })
                .fail(function(error) {
                    $widget_panel.html(self.render({
                        ref: '/templates/error.twig'
                    }, {
                        error_message: self.i18n('error.load_failed')
                    }));
                });

            return true;
        };

        /**
         * Bind actions in lead card panel
         */
        this.bindLeadCardActions = function($panel) {
            // Send suggested message
            $panel.on('click', '.js-saleswhisper-send-message', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var message = $btn.data('message');
                var lead_id = $btn.data('lead-id');
                var channel = $btn.data('channel') || 'whatsapp';

                $btn.addClass('loading');

                self.apiRequest('/widget/lead/' + lead_id + '/send-message', 'POST', {
                    message: message,
                    channel: channel
                })
                    .then(function(data) {
                        self.showNotification('success', self.i18n('notification.message_sent'));
                        $btn.addClass('sent').html('&#10004; ' + self.i18n('button.sent'));
                        // Refresh to show updated conversation
                        setTimeout(function() {
                            self.renderLeadCard();
                        }, 1000);
                    })
                    .fail(function() {
                        self.showNotification('error', self.i18n('error.send_failed'));
                    })
                    .always(function() {
                        $btn.removeClass('loading');
                    });
            });

            // Generate new message
            $panel.on('click', '.js-saleswhisper-generate', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var lead_id = $btn.data('lead-id');
                var context = $btn.data('context') || 'follow_up';

                $btn.addClass('loading');

                self.apiRequest('/widget/lead/' + lead_id + '/generate-message', 'POST', {
                    context: context
                })
                    .then(function(data) {
                        // Show generated message in editable area
                        var $messageArea = $panel.find('.js-saleswhisper-message-preview');
                        if (data.message) {
                            $messageArea.val(data.message);
                            $messageArea.closest('.saleswhisper-message-editor').show();
                        }
                    })
                    .fail(function() {
                        self.showNotification('error', self.i18n('error.generate_failed'));
                    })
                    .always(function() {
                        $btn.removeClass('loading');
                    });
            });

            // Send custom message
            $panel.on('click', '.js-saleswhisper-send-custom', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var lead_id = $btn.data('lead-id');
                var message = $panel.find('.js-saleswhisper-message-preview').val();
                var channel = $panel.find('[name="channel"]:checked').val() || 'whatsapp';

                if (!message.trim()) {
                    self.showNotification('error', self.i18n('error.empty_message'));
                    return;
                }

                $btn.addClass('loading');

                self.apiRequest('/widget/lead/' + lead_id + '/send-message', 'POST', {
                    message: message,
                    channel: channel
                })
                    .then(function(data) {
                        self.showNotification('success', self.i18n('notification.message_sent'));
                        $panel.find('.saleswhisper-message-editor').hide();
                        $panel.find('.js-saleswhisper-message-preview').val('');
                        self.renderLeadCard();
                    })
                    .fail(function() {
                        self.showNotification('error', self.i18n('error.send_failed'));
                    })
                    .always(function() {
                        $btn.removeClass('loading');
                    });
            });

            // Toggle auto-response
            $panel.on('change', '.js-saleswhisper-auto-response', function(e) {
                var enabled = $(this).is(':checked');
                var lead_id = $(this).data('lead-id');

                self.apiRequest('/widget/lead/' + lead_id + '/auto-response', 'POST', {
                    enabled: enabled
                })
                    .then(function() {
                        self.showNotification('success',
                            enabled ? self.i18n('notification.auto_enabled') : self.i18n('notification.auto_disabled')
                        );
                    })
                    .fail(function() {
                        $(e.target).prop('checked', !enabled);
                        self.showNotification('error', self.i18n('error.toggle_failed'));
                    });
            });

            // Copy message to clipboard
            $panel.on('click', '.js-saleswhisper-copy', function(e) {
                e.preventDefault();
                var message = $(this).data('message');

                if (navigator.clipboard) {
                    navigator.clipboard.writeText(message).then(function() {
                        self.showNotification('success', self.i18n('notification.copied'));
                    });
                }
            });

            // Toggle section
            $panel.on('click', '.js-saleswhisper-toggle', function(e) {
                e.preventDefault();
                $(this).closest('.saleswhisper-section').toggleClass('collapsed');
            });

            // View objection handler
            $panel.on('click', '.js-saleswhisper-objection', function(e) {
                e.preventDefault();
                var objection = $(this).data('objection');
                self.showObjectionModal(objection);
            });
        };

        /**
         * Show objection handling modal
         */
        this.showObjectionModal = function(objection) {
            self.apiRequest('/widget/objection/' + encodeURIComponent(objection), 'GET')
                .then(function(data) {
                    var modal = new (require('lib/components/base/modal'))({
                        class_name: 'saleswhisper-modal',
                        init: function($modal_body) {
                            $modal_body.html(self.render({
                                ref: '/templates/objection_modal.twig'
                            }, {
                                objection: objection,
                                responses: data.responses || [],
                                examples: data.examples || [],
                                tips: data.tips || []
                            }));

                            return true;
                        },
                        destroy: function() {}
                    });
                })
                .fail(function() {
                    self.showNotification('error', self.i18n('error.load_failed'));
                });
        };

        /**
         * Show notification
         */
        this.showNotification = function(type, message) {
            if (type === 'error') {
                APP.notifications.add_error({
                    header: 'Sales Whisper',
                    text: message
                });
            } else {
                APP.notifications.show_message({
                    header: 'Sales Whisper',
                    text: message
                });
            }
        };

        /**
         * Render settings page
         */
        this.renderSettings = function($settings_body) {
            $settings_body.html(self.render({
                ref: '/templates/settings.twig'
            }, {
                api_url: self.get_settings().api_url || '',
                api_key: self.get_settings().api_key || '',
                auto_response: self.get_settings().auto_response || false,
                status: self.get_status()
            }));

            // Test connection button
            $settings_body.on('click', '.js-saleswhisper-test', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var $status = $settings_body.find('.js-connection-status');

                $btn.addClass('loading');
                $status.text(self.i18n('settings.testing'));

                var api_url = $settings_body.find('[name="api_url"]').val();
                var api_key = $settings_body.find('[name="api_key"]').val();

                $.ajax({
                    url: api_url + '/widget/health',
                    type: 'GET',
                    headers: {
                        'X-API-Key': api_key
                    },
                    success: function(response) {
                        $status.text(self.i18n('settings.connection_ok')).addClass('success').removeClass('error');
                    },
                    error: function() {
                        $status.text(self.i18n('settings.connection_failed')).addClass('error').removeClass('success');
                    },
                    complete: function() {
                        $btn.removeClass('loading');
                    }
                });
            });

            return true;
        };

        /**
         * Widget callbacks
         */
        this.callbacks = {
            /**
             * Render callback
             */
            render: function() {
                var current_area = self.system().area;

                if (current_area === 'lcard') {
                    return self.renderLeadCard();
                }

                if (current_area === 'ccard') {
                    return self.renderContactCard();
                }

                return true;
            },

            /**
             * Init callback
             */
            init: function() {
                // Load custom CSS
                if (!$('#saleswhisper-manager-styles').length) {
                    $('head').append(
                        '<link id="saleswhisper-manager-styles" rel="stylesheet" href="/widgets/' + w_code + '/style.css">'
                    );
                }

                console.log('Sales Whisper Manager initialized');
                return true;
            },

            /**
             * Bind actions
             */
            bind_actions: function() {
                return true;
            },

            /**
             * Settings callback
             */
            settings: function($settings_body) {
                return self.renderSettings($settings_body);
            },

            /**
             * OnSave callback
             */
            onSave: function() {
                var api_url = $('[name="api_url"]').val();
                var api_key = $('[name="api_key"]').val();

                if (!api_url || !api_key) {
                    self.showNotification('error', self.i18n('error.settings_required'));
                    return false;
                }

                if (!api_url.match(/^https?:\/\//)) {
                    self.showNotification('error', self.i18n('error.invalid_url'));
                    return false;
                }

                return true;
            },

            /**
             * Destroy callback
             */
            destroy: function() {},

            /**
             * Digital Pipeline callback
             */
            dpSettings: function() {
                return true;
            }
        };

        return this;
    };

    return CustomWidget;
});
