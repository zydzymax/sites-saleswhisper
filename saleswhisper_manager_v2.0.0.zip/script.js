/**
 * Sales Whisper Manager Widget for AmoCRM/Kommo Marketplace
 * AI-powered sales assistant for managers
 * Version 2.0.0
 */
define(['jquery', 'underscore'], function($, _) {
    var CustomWidget = function() {
        var self = this;
        var w_code = self.get_settings().widget_code;
        
        // API Configuration
        var API_BASE_URL = 'https://saleswhisper.pro/api';
        
        /**
         * Get current account ID
         */
        this.getAccountId = function() {
            return AMOCRM.constant('account').id;
        };
        
        /**
         * Make authenticated API request
         */
        this.apiRequest = function(endpoint, method, data) {
            var deferred = $.Deferred();
            var url = API_BASE_URL + endpoint;
            var accountId = this.getAccountId();
            
            $.ajax({
                url: url,
                type: method || 'GET',
                data: data ? JSON.stringify(data) : null,
                contentType: 'application/json',
                headers: {
                    'X-Account-Id': accountId
                },
                success: function(response) {
                    deferred.resolve(response);
                },
                error: function(xhr, status, error) {
                    console.error('Sales Whisper API Error:', error);
                    
                    // Handle not installed error
                    if (xhr.status === 403) {
                        self.showNotInstalledError();
                    }
                    
                    deferred.reject(error);
                }
            });
            
            return deferred.promise();
        };
        
        /**
         * Show not installed error
         */
        this.showNotInstalledError = function() {
            var $panel = $('[data-id="' + w_code + '"]');
            $panel.html(self.render({
                ref: '/templates/error.twig'
            }, {
                error_message: self.i18n('errors.not_installed')
            }));
        };
        
        /**
         * Render lead card panel with AI assistant
         */
        this.renderLeadCard = function() {
            var lead_id = AMOCRM.data.current_card.id;
            var $widget_panel = $('[data-id="' + w_code + '"]');
            
            if (!$widget_panel.length) {
                return false;
            }
            
            // Show loading state
            $widget_panel.html(self.render({
                ref: '/templates/loading.twig'
            }, {}));
            
            // Fetch AI assistant data
            self.apiRequest('/widget/lead/' + lead_id + '/assistant', 'GET')
                .then(function(data) {
                    $widget_panel.html(self.render({
                        ref: '/templates/lead_card.twig'
                    }, {
                        lead_id: lead_id,
                        lead_name: data.lead_name || '',
                        client_info: data.client_info || {},
                        conversation_history: data.conversation_history || [],
                        suggested_messages: data.suggested_messages || [],
                        deal_stage: data.deal_stage || 'new',
                        client_temperature: data.client_temperature || 'cold',
                        temperature_score: data.temperature_score || 0,
                        next_action: data.next_action || '',
                        talking_points: data.talking_points || [],
                        objections: data.objections || [],
                        buying_signals: data.buying_signals || [],
                        risks: data.risks || [],
                        auto_response_enabled: self.get_settings().auto_response || false
                    }));
                    
                    // Bind actions after render
                    self.bindLeadCardActions($widget_panel, lead_id);
                })
                .fail(function(error) {
                    $widget_panel.html(self.render({
                        ref: '/templates/error.twig'
                    }, {
                        error_message: self.i18n('errors.load_failed')
                    }));
                });
            
            return true;
        };
        
        /**
         * Bind lead card actions
         */
        this.bindLeadCardActions = function($panel, lead_id) {
            // Copy message to clipboard
            $panel.on('click', '.sw-copy-message', function(e) {
                e.preventDefault();
                var text = $(this).closest('.sw-message-item').find('.sw-message-text').text();
                self.copyToClipboard(text);
                $(this).text('✓').addClass('copied');
                setTimeout(function() {
                    $(e.target).text(self.i18n('lead_card.copy_message')).removeClass('copied');
                }, 2000);
            });
            
            // Send message
            $panel.on('click', '.sw-send-message', function(e) {
                e.preventDefault();
                var text = $(this).closest('.sw-message-item').find('.sw-message-text').text();
                self.sendMessage(lead_id, text);
            });
            
            // Generate new message
            $panel.on('click', '.sw-generate-btn', function(e) {
                e.preventDefault();
                var context = $(this).data('context') || 'follow_up';
                self.generateMessage(lead_id, context, $panel);
            });
            
            // Handle objection
            $panel.on('click', '.sw-objection-item', function(e) {
                e.preventDefault();
                var objection = $(this).text();
                self.showObjectionModal(objection, lead_id);
            });
        };
        
        /**
         * Copy text to clipboard
         */
        this.copyToClipboard = function(text) {
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text);
            } else {
                var textarea = document.createElement('textarea');
                textarea.value = text;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
            }
        };
        
        /**
         * Send message to client
         */
        this.sendMessage = function(lead_id, message) {
            self.apiRequest('/widget/lead/' + lead_id + '/send', 'POST', {
                message: message,
                channel: 'whatsapp'
            }).then(function(response) {
                if (response.success) {
                    // Show success notification
                    self.showNotification('Сообщение отправлено', 'success');
                }
            }).fail(function() {
                self.showNotification(self.i18n('errors.send_failed'), 'error');
            });
        };
        
        /**
         * Generate new message
         */
        this.generateMessage = function(lead_id, context, $panel) {
            var $btn = $panel.find('.sw-generate-btn[data-context="' + context + '"]');
            $btn.addClass('loading').prop('disabled', true);
            
            self.apiRequest('/widget/lead/' + lead_id + '/generate', 'POST', {
                context: context
            }).then(function(response) {
                if (response.messages && response.messages.length > 0) {
                    // Add new messages to UI
                    var $messages = $panel.find('.sw-suggested-messages');
                    response.messages.forEach(function(msg) {
                        var html = '<div class="sw-message-item sw-message-new">' +
                            '<div class="sw-message-text">' + msg.text + '</div>' +
                            '<div class="sw-message-actions">' +
                            '<button class="sw-copy-message">' + self.i18n('lead_card.copy_message') + '</button>' +
                            '<button class="sw-send-message">' + self.i18n('lead_card.send_message') + '</button>' +
                            '</div></div>';
                        $messages.prepend(html);
                    });
                }
            }).fail(function() {
                self.showNotification(self.i18n('errors.generation_failed'), 'error');
            }).always(function() {
                $btn.removeClass('loading').prop('disabled', false);
            });
        };
        
        /**
         * Show objection handling modal
         */
        this.showObjectionModal = function(objection, lead_id) {
            var modal = $('<div class="sw-modal-overlay"></div>');
            modal.html(self.render({
                ref: '/templates/loading.twig'
            }, {}));
            $('body').append(modal);
            
            self.apiRequest('/widget/objection/handle', 'POST', {
                objection_text: objection,
                deal_context: 'lead_' + lead_id
            }).then(function(response) {
                modal.html(self.render({
                    ref: '/templates/objection_modal.twig'
                }, {
                    objection: response.original_objection,
                    objection_type: response.objection_type,
                    responses: response.response_options,
                    tips: response.tips
                }));
                
                // Bind modal actions
                modal.on('click', '.sw-modal-close, .sw-modal-overlay', function(e) {
                    if (e.target === this) {
                        modal.remove();
                    }
                });
                
                modal.on('click', '.sw-copy-response', function(e) {
                    e.preventDefault();
                    var text = $(this).closest('.sw-response-item').find('.sw-response-text').text();
                    self.copyToClipboard(text);
                    self.showNotification('Скопировано', 'success');
                });
            }).fail(function() {
                modal.remove();
                self.showNotification(self.i18n('errors.load_failed'), 'error');
            });
        };
        
        /**
         * Render contact card panel
         */
        this.renderContactCard = function() {
            var contact_id = AMOCRM.data.current_card.id;
            var $widget_panel = $('[data-id="' + w_code + '"]');
            
            if (!$widget_panel.length) {
                return false;
            }
            
            $widget_panel.html(self.render({
                ref: '/templates/loading.twig'
            }, {}));
            
            self.apiRequest('/widget/contact/' + contact_id + '/profile', 'GET')
                .then(function(data) {
                    $widget_panel.html(self.render({
                        ref: '/templates/contact_card.twig'
                    }, {
                        contact_id: contact_id,
                        contact_name: data.contact_name || '',
                        phone: data.phone || '',
                        email: data.email || '',
                        company: data.company || '',
                        total_interactions: data.total_interactions || 0,
                        total_deals: data.total_deals || 0,
                        won_deals: data.won_deals || 0,
                        personality_profile: data.personality_profile || {},
                        communication_style: data.communication_style || 'formal',
                        best_contact_time: data.best_contact_time || '',
                        interests: data.interests || [],
                        past_objections: data.past_objections || []
                    }));
                })
                .fail(function(error) {
                    $widget_panel.html(self.render({
                        ref: '/templates/error.twig'
                    }, {
                        error_message: self.i18n('errors.load_failed')
                    }));
                });
            
            return true;
        };
        
        /**
         * Render settings page
         */
        this.renderSettings = function($modal) {
            var accountId = this.getAccountId();
            var $content = $modal.find('.widget_settings_block__fields');
            
            $content.html(self.render({
                ref: '/templates/loading.twig'
            }, {}));
            
            self.apiRequest('/widget/settings/' + accountId, 'GET')
                .then(function(settings) {
                    $content.html(self.render({
                        ref: '/templates/settings.twig'
                    }, {
                        settings: settings
                    }));
                })
                .fail(function() {
                    $content.html('<p>' + self.i18n('errors.load_failed') + '</p>');
                });
            
            return true;
        };
        
        /**
         * Save settings
         */
        this.saveSettings = function() {
            var accountId = this.getAccountId();
            var settings = {
                enabled: $('#sw-auto-response').is(':checked'),
                working_hours_only: $('#sw-working-hours-only').is(':checked'),
                working_hours_start: $('#sw-working-hours-start').val(),
                working_hours_end: $('#sw-working-hours-end').val(),
                response_delay_seconds: parseInt($('#sw-response-delay').val()) || 30
            };
            
            return self.apiRequest('/widget/settings/' + accountId, 'POST', settings);
        };
        
        /**
         * Show notification
         */
        this.showNotification = function(message, type) {
            // Use AmoCRM notification system if available
            if (typeof AMOCRM.notifications !== 'undefined') {
                AMOCRM.notifications.show_message({
                    text: message,
                    type: type || 'info'
                });
            } else {
                console.log('[SalesWhisper]', type, message);
            }
        };
        
        /**
         * Widget callbacks
         */
        this.callbacks = {
            render: function() {
                return true;
            },
            
            init: function() {
                console.log('Sales Whisper Manager initialized');
                return true;
            },
            
            bind_actions: function() {
                return true;
            },
            
            settings: function($modal) {
                return self.renderSettings($modal);
            },
            
            advancedSettings: function() {
                return true;
            },
            
            onSave: function() {
                return self.saveSettings();
            },
            
            destroy: function() {
                return true;
            },
            
            contacts: {
                selected: function() {
                    return true;
                }
            },
            
            leads: {
                selected: function() {
                    return true;
                }
            },
            
            // Lead card widget panel
            'lcard-1': function() {
                return self.renderLeadCard();
            },
            
            // Contact card widget panel
            'ccard-1': function() {
                return self.renderContactCard();
            },
            
            // Digital Pipeline
            dpSettings: function() {
                return true;
            }
        };
        
        return this;
    };
    
    return CustomWidget;
});
