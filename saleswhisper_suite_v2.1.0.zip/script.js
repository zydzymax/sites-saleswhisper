/**
 * Sales Whisper Suite - AmoCRM/Kommo Marketplace Widget
 * Includes: AI Seller (for managers) + Head of Sales (for executives)
 * Version 2.1.0
 */
define(['jquery', 'underscore'], function($, _) {
    var CustomWidget = function() {
        var self = this;
        var w_code = self.get_settings().widget_code;
        
        // API Configuration
        var API_BASE_URL = 'https://saleswhisper.pro/api';
        
        // Module states
        var modules = {
            ai_seller: true,
            head_of_sales: true
        };
        
        /**
         * Get current account ID
         */
        this.getAccountId = function() {
            return AMOCRM.constant('account').id;
        };
        
        /**
         * Check if module is enabled
         */
        this.isModuleEnabled = function(moduleName) {
            var settings = self.get_settings();
            if (moduleName === 'ai_seller') {
                return settings.module_ai_seller !== false;
            }
            if (moduleName === 'head_of_sales') {
                return settings.module_head_of_sales !== false;
            }
            return true;
        };
        
        /**
         * Make authenticated API request
         */
        this.apiRequest = function(endpoint, method, data) {
            var deferred = $.Deferred();
            var url = API_BASE_URL + endpoint;
            var accountId = this.getAccountId();
            
            $.ajax({
                url: url,
                type: method || 'GET',
                data: data ? JSON.stringify(data) : null,
                contentType: 'application/json',
                headers: {
                    'X-Account-Id': accountId
                },
                success: function(response) {
                    deferred.resolve(response);
                },
                error: function(xhr, status, error) {
                    console.error('Sales Whisper API Error:', error);
                    if (xhr.status === 403) {
                        self.showNotInstalledError();
                    }
                    deferred.reject(error);
                }
            });
            
            return deferred.promise();
        };
        
        /**
         * Show not installed error
         */
        this.showNotInstalledError = function() {
            var $panel = $('[data-id="' + w_code + '"]');
            $panel.html(self.render({
                ref: '/templates/error.twig'
            }, {
                error_message: self.i18n('errors.not_installed')
            }));
        };
        
        /**
         * Show module disabled message
         */
        this.showModuleDisabled = function($panel) {
            $panel.html(self.render({
                ref: '/templates/error.twig'
            }, {
                error_message: self.i18n('errors.module_disabled')
            }));
        };
        
        // =============================================
        // AI SELLER MODULE - For Sales Managers
        // =============================================
        
        /**
         * Render lead card panel with AI assistant
         */
        this.renderLeadCard = function() {
            if (!self.isModuleEnabled('ai_seller')) {
                return false;
            }
            
            var lead_id = AMOCRM.data.current_card.id;
            var $widget_panel = $('[data-id="' + w_code + '"]');
            
            if (!$widget_panel.length) {
                return false;
            }
            
            // Show loading state
            $widget_panel.html(self.render({
                ref: '/templates/loading.twig'
            }, {}));
            
            // Fetch AI assistant data
            self.apiRequest('/widget/lead/' + lead_id + '/assistant', 'GET')
                .then(function(data) {
                    $widget_panel.html(self.render({
                        ref: '/templates/lead_card.twig'
                    }, {
                        lead_id: lead_id,
                        lead_name: data.lead_name || '',
                        client_info: data.client_info || {},
                        conversation_history: data.conversation_history || [],
                        suggested_messages: data.suggested_messages || [],
                        deal_stage: data.deal_stage || 'new',
                        client_temperature: data.client_temperature || 'cold',
                        temperature_score: data.temperature_score || 0,
                        next_action: data.next_action || '',
                        talking_points: data.talking_points || [],
                        objections: data.objections || [],
                        buying_signals: data.buying_signals || [],
                        risks: data.risks || []
                    }));
                    
                    self.bindLeadCardEvents($widget_panel, lead_id);
                })
                .fail(function() {
                    $widget_panel.html(self.render({
                        ref: '/templates/error.twig'
                    }, {
                        error_message: self.i18n('errors.load_failed')
                    }));
                });
                
            return true;
        };
        
        /**
         * Bind lead card events
         */
        this.bindLeadCardEvents = function($panel, lead_id) {
            // Generate message button
            $panel.on('click', '[data-sw-generate]', function() {
                var context = $(this).data('context') || 'general';
                self.generateMessage(lead_id, context, $panel);
            });
            
            // Send message button
            $panel.on('click', '[data-sw-send]', function() {
                var message = $(this).closest('.sw-message-item').find('.sw-message-text').text();
                self.sendMessage(lead_id, message);
            });
            
            // Copy message button
            $panel.on('click', '[data-sw-copy]', function() {
                var message = $(this).closest('.sw-message-item').find('.sw-message-text').text();
                self.copyToClipboard(message);
            });
            
            // Objection handling
            $panel.on('click', '[data-sw-objection]', function() {
                var objection = $(this).data('objection');
                self.showObjectionModal(lead_id, objection);
            });
        };
        
        /**
         * Generate personalized message
         */
        this.generateMessage = function(lead_id, context, $panel) {
            var $btn = $panel.find('[data-sw-generate]');
            $btn.prop('disabled', true).text(self.i18n('buttons.loading') || '...');
            
            self.apiRequest('/widget/lead/' + lead_id + '/generate-message', 'POST', {
                context: context,
                tone: 'professional'
            })
            .then(function(data) {
                if (data.message) {
                    var $messages = $panel.find('.sw-suggested-messages');
                    $messages.prepend(
                        '<div class="sw-message-item sw-message-new">' +
                        '<div class="sw-message-text">' + data.message + '</div>' +
                        '<div class="sw-message-actions">' +
                        '<button data-sw-send class="sw-btn sw-btn-primary">' + self.i18n('lead_card.send_message') + '</button>' +
                        '<button data-sw-copy class="sw-btn">' + self.i18n('lead_card.copy_message') + '</button>' +
                        '</div></div>'
                    );
                }
            })
            .always(function() {
                $btn.prop('disabled', false).text(self.i18n('lead_card.generate_message'));
            });
        };
        
        /**
         * Show objection handling modal
         */
        this.showObjectionModal = function(lead_id, objection) {
            self.apiRequest('/widget/lead/' + lead_id + '/handle-objection', 'POST', {
                objection: objection
            })
            .then(function(data) {
                var modal = self.render({
                    ref: '/templates/objection_modal.twig'
                }, {
                    objection: objection,
                    objection_type: data.type || 'general',
                    responses: data.responses || [],
                    tips: data.tips || []
                });
                
                $('body').append(modal);
                $('.sw-modal-overlay').on('click', function(e) {
                    if ($(e.target).hasClass('sw-modal-overlay')) {
                        $(this).remove();
                    }
                });
            });
        };
        
        /**
         * Render contact card
         */
        this.renderContactCard = function() {
            if (!self.isModuleEnabled('ai_seller')) {
                return false;
            }
            
            var contact_id = AMOCRM.data.current_card.id;
            var $widget_panel = $('[data-id="' + w_code + '"]');
            
            if (!$widget_panel.length) {
                return false;
            }
            
            $widget_panel.html(self.render({
                ref: '/templates/loading.twig'
            }, {}));
            
            self.apiRequest('/widget/contact/' + contact_id + '/profile', 'GET')
                .then(function(data) {
                    $widget_panel.html(self.render({
                        ref: '/templates/contact_card.twig'
                    }, data));
                })
                .fail(function() {
                    $widget_panel.html(self.render({
                        ref: '/templates/error.twig'
                    }, {
                        error_message: self.i18n('errors.load_failed')
                    }));
                });
                
            return true;
        };
        
        // =============================================
        // HEAD OF SALES MODULE - For Executives
        // =============================================
        
        /**
         * Render Head of Sales dashboard
         */
        this.renderHOSDashboard = function() {
            if (!self.isModuleEnabled('head_of_sales')) {
                return false;
            }
            
            var $widget_panel = $('[data-id="' + w_code + '"]');
            
            if (!$widget_panel.length) {
                return false;
            }
            
            $widget_panel.html('<div class="sw-loading">' + self.i18n('hos.loading') + '</div>');
            
            var period = self.get_settings().analytics_period || 30;
            
            self.apiRequest('/widget/hos/dashboard?period=' + period, 'GET')
                .then(function(data) {
                    $widget_panel.html(self.render({
                        ref: '/templates/hos_dashboard.twig'
                    }, {
                        total_deals: data.total_deals || 0,
                        total_revenue: self.formatCurrency(data.total_revenue || 0),
                        conversion_rate: data.conversion_rate || 0,
                        avg_deal_time: data.avg_deal_time || '-',
                        deals_change: self.formatChange(data.deals_change),
                        deals_change_class: data.deals_change >= 0 ? 'positive' : 'negative',
                        revenue_change: self.formatChange(data.revenue_change),
                        revenue_change_class: data.revenue_change >= 0 ? 'positive' : 'negative',
                        conversion_change: self.formatChange(data.conversion_change),
                        conversion_change_class: data.conversion_change >= 0 ? 'positive' : 'negative',
                        cycle_change: self.formatChange(data.cycle_change),
                        cycle_change_class: data.cycle_change <= 0 ? 'positive' : 'negative',
                        managers: data.managers || [],
                        funnel_stages: data.funnel_stages || [],
                        insights: data.insights || [],
                        forecast_revenue: self.formatCurrency(data.forecast_revenue || 0),
                        forecast_deals: data.forecast_deals || 0,
                        forecast_confidence: data.forecast_confidence || 0
                    }));
                    
                    self.bindHOSEvents($widget_panel);
                })
                .fail(function() {
                    $widget_panel.html(self.render({
                        ref: '/templates/error.twig'
                    }, {
                        error_message: self.i18n('errors.load_failed')
                    }));
                });
                
            return true;
        };
        
        /**
         * Bind Head of Sales events
         */
        this.bindHOSEvents = function($panel) {
            // Period selector
            $panel.on('change', '[data-sw-period]', function() {
                var period = $(this).val();
                self.refreshHOSDashboard(period);
            });
            
            // Refresh button
            $panel.on('click', '[data-sw-refresh]', function() {
                var period = $panel.find('[data-sw-period]').val() || 30;
                self.refreshHOSDashboard(period);
            });
            
            // Export button
            $panel.on('click', '[data-sw-export]', function() {
                self.exportAnalytics();
            });
        };
        
        /**
         * Refresh HOS dashboard
         */
        this.refreshHOSDashboard = function(period) {
            self.renderHOSDashboard();
        };
        
        /**
         * Export analytics
         */
        this.exportAnalytics = function() {
            var period = $('[data-sw-period]').val() || 30;
            window.open(API_BASE_URL + '/widget/hos/export?period=' + period + '&account_id=' + self.getAccountId(), '_blank');
        };
        
        // =============================================
        // UTILITY FUNCTIONS
        // =============================================
        
        /**
         * Format currency
         */
        this.formatCurrency = function(value) {
            if (typeof value !== 'number') return value;
            return new Intl.NumberFormat('ru-RU', {
                style: 'currency',
                currency: 'RUB',
                minimumFractionDigits: 0
            }).format(value);
        };
        
        /**
         * Format change percentage
         */
        this.formatChange = function(value) {
            if (typeof value !== 'number') return '-';
            var sign = value >= 0 ? '+' : '';
            return sign + value.toFixed(1) + '%';
        };
        
        /**
         * Copy text to clipboard
         */
        this.copyToClipboard = function(text) {
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text);
            } else {
                var $temp = $('<textarea>');
                $('body').append($temp);
                $temp.val(text).select();
                document.execCommand('copy');
                $temp.remove();
            }
        };
        
        /**
         * Send message via amoCRM
         */
        this.sendMessage = function(lead_id, message) {
            // Use amoCRM API to send message
            console.log('Sending message to lead', lead_id, message);
            // Implementation depends on available channels
        };
        
        // =============================================
        // WIDGET LIFECYCLE
        // =============================================
        
        this.callbacks = {
            render: function() {
                return true;
            },
            
            init: function() {
                // Load widget settings
                var settings = self.get_settings();
                modules.ai_seller = settings.module_ai_seller !== false;
                modules.head_of_sales = settings.module_head_of_sales !== false;
                return true;
            },
            
            bind_actions: function() {
                return true;
            },
            
            settings: function() {
                return true;
            },
            
            onSave: function() {
                return true;
            },
            
            destroy: function() {
                // Cleanup
            },
            
            contacts: {
                selected: function() {
                    // Bulk contact selection
                }
            },
            
            leads: {
                selected: function() {
                    // Bulk lead selection
                }
            },
            
            // Digital Pipeline trigger
            dpSettings: function() {
                return true;
            },
            
            advancedSettings: function() {
                return true;
            }
        };
        
        return this;
    };
    
    return CustomWidget;
});
