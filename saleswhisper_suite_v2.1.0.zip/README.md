# Sales Whisper Manager - AI Sales Assistant for AmoCRM/Kommo

## Overview

Sales Whisper Manager is an AI-powered sales assistant widget for AmoCRM/Kommo that helps sales managers:

- **Generate personalized messages** based on client context and conversation history
- **Handle objections** with AI-suggested responses
- **Track client temperature** (cold/warm/hot) based on conversation analysis
- **Get talking points** and recommended next actions
- **Identify buying signals** in real-time

## Features

### Lead Card Integration
- AI assistant panel on every lead card
- Real-time client analysis and recommendations
- One-click message generation
- Objection handling suggestions

### Contact Card Integration
- Client profile summary
- Communication history analysis
- Personalized approach recommendations

### Digital Pipeline
- Automated stage-based actions
- Smart notifications
- Auto-response capability (optional)

### Settings
- Auto-response toggle
- Working hours configuration
- Response delay settings

## Installation

### Via AmoCRM Marketplace

1. Go to Settings > Integrations in your AmoCRM account
2. Search for "Sales Whisper Manager"
3. Click "Install"
4. Authorize the application
5. Configure settings in the widget panel

### Technical Requirements

- AmoCRM account with API access
- Active subscription to Sales Whisper

## Configuration

### Basic Settings

| Setting | Description | Default |
|---------|-------------|---------|
| Auto Response | Enable automatic responses | Off |
| Working Hours Only | Limit auto-responses to business hours | On |
| Working Hours Start | Start of working hours | 09:00 |
| Working Hours End | End of working hours | 18:00 |
| Response Delay | Minimum delay between responses (seconds) | 30 |

### Digital Pipeline Settings

| Setting | Description | Default |
|---------|-------------|---------|
| Enable in Pipeline | Use widget in digital pipeline | On |
| Auto Send Messages | Automatically send generated messages | Off |
| Trigger Stages | Comma-separated stage IDs for triggers | (empty) |

## API Endpoints

The widget communicates with the Sales Whisper API at `https://saleswhisper.pro/api`

### Authentication

All requests include the `X-Account-Id` header with your AmoCRM account ID.

### Endpoints

#### Get Lead Assistant Data
```
GET /api/widget/lead/{lead_id}/assistant
```

Response:
```json
{
  "lead_name": "John Doe",
  "client_info": {...},
  "conversation_history": [...],
  "suggested_messages": [...],
  "deal_stage": "negotiation",
  "client_temperature": "warm",
  "temperature_score": 65,
  "next_action": "Follow up on pricing",
  "talking_points": [...],
  "objections": [...],
  "buying_signals": [...]
}
```

#### Generate Message
```
POST /api/widget/lead/{lead_id}/generate-message
```

Request:
```json
{
  "context": "pricing discussion",
  "tone": "professional",
  "goal": "close deal"
}
```

#### Handle Objection
```
POST /api/widget/lead/{lead_id}/handle-objection
```

Request:
```json
{
  "objection": "Price is too high"
}
```

## OAuth Flow

### Installation Flow

1. User installs widget from marketplace
2. AmoCRM redirects to `https://saleswhisper.pro/api/amocrm/callback` with auth code
3. Server exchanges code for access/refresh tokens
4. Tokens stored securely for API access

### Webhook Events

The widget receives webhook notifications at `https://saleswhisper.pro/api/amocrm/webhook` for:

- `install` - Widget installed
- `uninstall` - Widget removed
- `settings_update` - Settings changed

## Troubleshooting

### Widget Not Loading

1. Clear browser cache
2. Check browser console for errors
3. Verify AmoCRM account has API access
4. Contact support at support@saleswhisper.pro

### API Errors

| Error Code | Description | Solution |
|------------|-------------|----------|
| 403 | Widget not installed | Reinstall widget |
| 401 | Authentication failed | Re-authorize widget |
| 429 | Rate limit exceeded | Wait and retry |
| 500 | Server error | Contact support |

### Common Issues

**Q: Messages not generating?**
A: Check that the lead has conversation history. The AI needs context to generate relevant messages.

**Q: Temperature always showing "cold"?**
A: The system needs sufficient interaction data. After 2-3 conversations, temperature calculation becomes more accurate.

**Q: Auto-response not working?**
A: Verify that:
1. Auto-response is enabled in settings
2. Current time is within working hours (if enabled)
3. Response delay has passed since last message

## Support

- **Email**: support@saleswhisper.pro
- **Website**: https://saleswhisper.pro/support
- **Documentation**: https://saleswhisper.pro/docs

## Privacy & Security

- All data transmitted over HTTPS
- OAuth 2.0 authentication
- Tokens stored encrypted
- No message content stored permanently
- GDPR compliant

## Changelog

### Version 2.0.0
- Complete marketplace release
- OAuth 2.0 integration
- New API v2 with improved authentication
- Digital pipeline support
- Enhanced AI capabilities

### Version 1.0.0
- Initial private widget release
- Basic lead card integration
- Message generation

---

(c) 2025 Sales Whisper. All rights reserved.
